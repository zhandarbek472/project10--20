from logging.config import fileConfig
from sqlalchemy.ext.asyncio import async_engine_from_config
from sqlalchemy.ext.asyncio import AsyncConnection
from alembic import context
from sqlalchemy import pool
import asyncio
import os
import sys

from dotenv import load_dotenv

# .env файлынан айнымалыларды жүктейміз
load_dotenv()

# app/ ішін импорттау үшін sys.path кеңейту
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# SQLAlchemy модельдерін импорттаймыз
from app.models import Base

# Alembic конфигурациясы
config = context.config

# .env-тен алынған URL-ды қолданамыз
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise Exception("DATABASE_URL not set in .env")

config.set_main_option("sqlalchemy.url", DATABASE_URL)

# Логгер конфигурациясы
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Миграция үшін metadata орнату
target_metadata = Base.metadata


def run_migrations_offline():
    """Offline режимдегі миграция."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online():
    """Online режимдегі миграция (async)."""
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    async with connectable.connect() as connection:
        await connection.run_sync(
            lambda conn: context.configure(
                connection=conn,
                target_metadata=target_metadata,
                compare_type=True,  # тип өзгерістерін де бақылау үшін
            )
        )
        async with context.begin_transaction():
            await context.run_migrations()

    await connectable.dispose()


# Entry point
if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
